Hydrant inspection MVP kit

Unzip to C:\temp\hydrant-mvp so build_hydrant_gdb.py sits next to the data folder.
The setup steps are in the sfpuc-hydrant-mvp guide (docs/index.md), starting with step 1.
